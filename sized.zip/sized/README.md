PRIMARY VERSION OF WEBSITE FOR MAPL 

developed in bootstrap 4. 

developed by weaver
auther: Hasan Mahmud